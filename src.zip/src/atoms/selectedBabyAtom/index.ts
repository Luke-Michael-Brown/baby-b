import { atom } from 'jotai';

export const selectedBaby = atom<string | null>(null);
export default selectedBaby;
